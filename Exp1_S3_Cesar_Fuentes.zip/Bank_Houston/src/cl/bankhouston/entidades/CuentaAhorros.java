//EVALUACION SUMATIVA
package cl.bankhouston.entidades;

import java.util.InputMismatchException;


public class CuentaAhorros extends CuentaBancaria{

    //ATRIBUTOS ENCAPSULADOS
    private int limiteDeGiros=4;
    private double interesAFavor;
    
    
    //CONSTRUCTOR
    public CuentaAhorros() {
        super("Cuenta_Ahorro", 0);
    }
    
    @Override
    public void depositar(){
        int montoDepositado=0;
        do{
         try{
             System.out.println("¿Qué monto desea depositar en su cuenta?");
             montoDepositado=sc.nextInt();
             
             if(montoDepositado<=0){
                 System.out.println("El monto a depositar debe ser mayor a cero.");
             }else{
                 this.calcularInteres();
                 double depositoConInteres= montoDepositado + (montoDepositado * this.interesAFavor );
                 double nuevoSaldo= this.getSaldo()+ depositoConInteres;
                 this.setSaldo((int)nuevoSaldo);
                 
                 System.out.println("====¡Deposito realizado de manera exitosa!====");
                 System.out.println("Tu nuevo saldo es $ " + this.getSaldo() + "\n");
             }    
            } catch (InputMismatchException e){
                System.out.println("****¡ERROR!****");
                System.out.println("Debes ingresar un monto valido.");
                sc.next();
                montoDepositado=0;
            }
        }while(montoDepositado<=0);
    }
    
    //GERERA UN INTERES A FAVOR POR DEPOSITO
    @Override
    public void calcularInteres() {
       System.out.println("El monto a depositar tendra un interes a favor en su cuenta");
       System.out.println("Por favor confirme el monto a depositar.");
       int montoDepositado=sc.nextInt();
       if(montoDepositado>=1000 && montoDepositado<=2000){
           interesAFavor= 0.10; //interes a favor del 10%
           System.out.println("Su interes a favor es del 10%");
       } if (montoDepositado>=2100 && montoDepositado<=5000){
           interesAFavor= 0.15; //interes a favor del 15%
           System.out.println("Su interes a favor es del 15%");
       } if (montoDepositado>=5100){
           interesAFavor=0.20; //interes del 20%
           System.out.println("Su interes a favor es del 20%");
       }
    }

    @Override
    public void girar() {
        int montoGirado=0;
        do{
         try{
             if(limiteDeGiros==0){
                 System.out.println("Ya alcanzaste el limite de giros para esta cuenta.");
                 System.out.println("Tu saldo actual es de $ " + this.getSaldo() + "\n");
             } else {
                 if(this.getSaldo()==0){
                     System.out.println("Tu saldo actual es de $0. Por ende, no puedes realizar ningun giro.");
                 }else{
                     System.out.println("¿Qué monto deseas girar desde tu cuenta ?");
                     montoGirado=sc.nextInt();
                     if(montoGirado>this.getSaldo()){
                         System.out.println("El monto a girar debe ser menor o igual que tu saldo.");
                         System.out.println("Tu saldo actual es de $ " + this.getSaldo());
                     }else{
                         int nuevoSaldo=this.getSaldo()-montoGirado;
                         this.setSaldo(nuevoSaldo);
                         montoGirado=0;
                         this.limiteDeGiros --;
                         System.out.println("====¡Giro realizado de manera exitosa!====");
                         System.out.println("Tu nuevo saldo es de $ "+this.getSaldo()+"\n");
                         System.out.println("Quedan disponibles " + limiteDeGiros + "giros.");
                     }
                 }
             }    
            }catch(InputMismatchException e){
                System.out.println("****¡ERROR!****");
                System.out.println("Debes ingresar un monto valido.");
                sc.next();
                montoGirado=0;
            }
        }while(montoGirado>0 && montoGirado>this.getSaldo());
    }
    
}
