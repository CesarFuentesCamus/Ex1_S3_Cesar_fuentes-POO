//EVALUACION SUMATIVA
package cl.bankhouston.entidades;

import java.util.InputMismatchException;


public class CuentaInversion extends CuentaBancaria{

    //ATRIBUTOS ENCAPSULADOS
    
    private int limiteSaldo=200000;
    private double interesEnContra=100;
    
    //CONSTRUCTOR
    public CuentaInversion() {
        super("Cuenta_Inversion", 200000);
    }
    
    @Override
    public void depositar(){
        int montoDepositado=0;
        do{
         try{
             System.out.println("¿Qué monto desea depositar a su cuenta?");
             montoDepositado=sc.nextInt();
             if(limiteSaldo==this.getSaldo()){
                 System.out.println("Su linea de credito esta completa, no puede depositar.");
             }
             if(montoDepositado+this.getSaldo()<=limiteSaldo){
                 int nuevoSaldo=this.getSaldo()+montoDepositado;
                 this.setSaldo(nuevoSaldo);
                 System.out.println("====¡Pago realizado de manera exitosa!====");
                 System.out.println("Tu nuevo saldo en la linea de credito es $ " + this.getSaldo() + "\n");
             } 
         }catch(InputMismatchException e){
                System.out.println("****¡ERROR!****");
                System.out.println("Debes ingresar un monto valido.");
                sc.next();
                montoDepositado=0;   
            } 
         }while(montoDepositado<=0 || montoDepositado>this.limiteSaldo);
        }
    
    //LA CUENTA DE INVERSIÓN GENERA INTERES POR LA DEUDA.
    @Override
    public void calcularInteres() {
        
        System.out.println("El uso de la linea de credito tedra un interes de $" + interesEnContra + ""+ "pesos en su cuenta");
        } 

    @Override
    public void girar() {
      int montoGirado=0;
       do{
        try{
          if(this.getSaldo() ==0){
              System.out.println("Tu saldo actual es de $0.  No puedes realziar ningun giro debido al interes.");
          } else {
              System.out.println("¿Qué monto desea girar desde su cuenta?");
              montoGirado=sc.nextInt();
              
          } if(montoGirado>(this.getSaldo()-interesEnContra)){
              System.out.println("El monto a girar debe ser menor a tu saldo, incluyendo el interes.");
              System.out.println("Tu saldo actual es de $ " + this.getSaldo()+"\n");
          }else {
              this.calcularInteres();
              int nuevoSaldo=(int) ((this.getSaldo()-montoGirado)-interesEnContra);
              this.setSaldo(nuevoSaldo);
              montoGirado=0;
              System.out.println("====¡Giro realizado de manera exitosa!====");
              System.out.println("Tu nuevo saldo es $ " + this.getSaldo() + "\n");
          }
        }catch (InputMismatchException e){
                System.out.println("****¡ERROR!****");
                System.out.println("Debes ingresar un monto valido.");
                sc.next();
                montoGirado=0;
       } 
       }while(montoGirado>0 && montoGirado>this.getSaldo()-interesEnContra); 
       }
}
    
    
    
    

    
    
    
    
 
    

