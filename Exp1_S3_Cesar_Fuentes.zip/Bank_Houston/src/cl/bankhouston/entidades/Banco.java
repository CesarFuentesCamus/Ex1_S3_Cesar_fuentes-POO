
package cl.bankhouston.entidades;

import cl.cliente.Cliente;
import java.util.ArrayList;
import java.util.Scanner;


public class Banco {
    
    Scanner sc = new Scanner (System.in);
    
    //ATRIBUTOS ENCAPSULADOS
    private String nombre;
    private Cliente cliente;
    private ArrayList<Cliente> listaClientes;

    public Banco(String nombre) {
        this.nombre=nombre;
        this.listaClientes=new ArrayList<>();
    }
    
    //GETTERS O ACCESADORES

    public String getNombre() {
        return nombre;
    }

    public Cliente getCliente() {
        return cliente;
    }
   
    //SETTERS

    public void setNombre(String nombre) {
        if(nombre != null){
            this.nombre=nombre;
        }
    }
    
    //METODO
    public boolean cantidadClientes(){
        return this.listaClientes.isEmpty();
    }
    
    public void registroCliente(){
        //variables
        String rutRegistro;
        String nombreRegistro;
        String apellidoPaternoRegistro;
        String apellidoMaternoRegistro;
        String domicilioRegistro;
        String comunaRegistro;
        String telefonoRegistro;
        int tipoDeCuenta;
        String numeroDeCuentaRegistro;
        
        cliente=new Cliente();
        
        System.out.println("Ingrese rut del cliente. (Con puntos y guion)");
        rutRegistro=sc.next();
        cliente.setRut(rutRegistro);
        sc.nextLine();
        
        System.out.println("Ingrese el nombre del cliente.");
        nombreRegistro=sc.next();
        cliente.setNombre(nombreRegistro);
        sc.nextLine();
        
        System.out.println("Ingrese el apellido paterno del cliente.");
        apellidoPaternoRegistro=sc.next();
        cliente.setApellidoPaterno(apellidoPaternoRegistro);
        sc.nextLine();
        
        System.out.println("Ingrese el apellido materno del  cliente.");
        apellidoMaternoRegistro=sc.next();
        cliente.setApellidoMaterno(apellidoMaternoRegistro);
        sc.nextLine();
        
        System.out.println("Ingrese el domicilio del paciente.");
        domicilioRegistro=sc.next();
        cliente.setDomicilio(domicilioRegistro);
        sc.nextLine();
        
        System.out.println("Ingrese comuna del cliente.");
        comunaRegistro=sc.next();
        cliente.setComnuna(comunaRegistro);
        sc.nextLine();
        
        System.out.println("Ingrese número de telefono del cliente. (Incluir nueve digitos)");
        telefonoRegistro=sc.next();
        cliente.setTelefono(telefonoRegistro);
        sc.nextLine();
        
        System.out.println("Elige el tipo de cuenta del cliente");
        System.out.println("1.-Cuenta Corriente.");
        System.out.println("2.-Cuenta de Ahorro."); //Deposito con intereses y con un limite de cuatro giros.
        System.out.println("3.-Cuenta de Inversión"); //con credito de $200.000 y comisión por cada giro.
        tipoDeCuenta=sc.nextInt();
        
        switch(tipoDeCuenta){
            case 1:
                cliente.setLaCuenta("Cuenta_Corriente");
                cliente.nuevaCuenta("Cuenta_Corriente");
                break;
            case 2:
                cliente.setLaCuenta("Cuenta_Ahorro");
                cliente.nuevaCuenta("Cuenta_Ahorro");
                break;
            case 3:
                cliente.setLaCuenta("Cuenta_Inversion");
                cliente.nuevaCuenta("Cuenta_Inversion");
                break;
                
        }
        
        System.out.println("Asignale un número de cuenta al cliente (número de nueve digitos)");
        numeroDeCuentaRegistro=sc.next();
        cliente.setNumeroDeCuenta(numeroDeCuentaRegistro);
        sc.nextLine();
        
        listaClientes.add(this.cliente);
        
        System.out.println("====¡CLIENTE CREADO DE MANERA EXITOSA!====");
          
    }
    
    public int listaClientesGuardados(){
        int indice = 1;
        for(Cliente cliente : listaClientes){
            System.out.println("[" + indice + "]" + cliente.getNombre());
            indice++;
        }
        return sc.nextInt()-1;
    }
   
    public Cliente clienteElegido(){
       Cliente objetoClienteElegido = listaClientes.get(listaClientesGuardados());
       return objetoClienteElegido;
       
    }
}
