//EVALUACION SUMATIVA
package cl.bankhouston.entidades;

import java.util.InputMismatchException;
import java.util.Scanner;

public class CuentaCorriente extends CuentaBancaria {

    private int sinInteres;
    
    //CONSTRUCTOR
    public CuentaCorriente() {
        this.setTipoDeCuenta("Cuenta Corriente");
    }
    
    //LA CUENTA CORRIENTE NO GENERA INTERES
    @Override
    public void calcularInteres() {
        sinInteres=0;
        //El profesor Alberto mensiono en su superclase realizada el día miercoles de la semana pasada, que en cuenta corriente lo ibmaos a dejar en cero, ya que acordamos con el curso que la cuenta corriente no generaba interes.
    }

    @Override
    public void girar() {
        int montoGirado=0;
        do{
         try{
             if(this.getSaldo()==0){
                 System.out.println("Tu saldo actual es de $0 pesos. No puedes realizar ningun tipo de giro");
             } else {
                 System.out.println("¿Qué monto deseas girar desde tu cuenta?");
                 montoGirado=sc.nextInt();  
             }if(montoGirado>this.getSaldo()){
                 System.out.println("El monto a girar debe ser menor o igual a tu saldo");
                 System.out.println("Tu saldo actual es de $ " + this.getSaldo() + "\n");
             } else{
                 int nuevoSaldo = this.getSaldo() - montoGirado;
                 this.setSaldo(nuevoSaldo);
                 montoGirado=0;
                 System.out.println("====¡Giro realizado de manera exitosa!====");
                 System.out.println("Tu nuevo saldo es $ " + this.getSaldo() + "\n");
             }  
         }catch (InputMismatchException e){
                System.out.println("****¡ERROR!****");
                System.out.println("Debes ingresar un monto valido.");
                montoGirado=0;       
         }
        } while(montoGirado>0 && montoGirado>this.getSaldo());
    }
    

    
}
