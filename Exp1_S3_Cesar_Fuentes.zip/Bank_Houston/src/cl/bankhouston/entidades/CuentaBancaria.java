
package cl.bankhouston.entidades;

import java.util.InputMismatchException;
import java.util.Scanner;


public abstract class CuentaBancaria {
    
    Scanner sc = new Scanner (System.in);
    
    //ATRIBUTOS ENCAPSULADOS
    private String tipoDeCuenta;
    private int saldo;

    
    //CONSTRUCTOR VACIO -> LE PEDIRE LOS DATOS AL CLIENTE.
    public CuentaBancaria() {
    }

    public CuentaBancaria(String tipoDeCuenta, int saldo) {
        setTipoDeCuenta (tipoDeCuenta);
        setSaldo(saldo);
    }
    
    //GETTERS O ACCESADORES 
    public String getTipoDeCuenta() {
        return tipoDeCuenta;
    }
    public int getSaldo() {
        return saldo;
    }
    
    //SETTERS O MUTADORES
    public void setTipoDeCuenta(String tipoDeCuenta) {
        this.tipoDeCuenta = tipoDeCuenta;
    }
    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    //Este metodo propio del programa segun lo visto en clases me permite ver si los datos se me estan guardando.

    @Override
    public String toString() {
        return "CuentaBancaria{" + "saldo=" + saldo + '}';
    }
   
    //METODOS NORMALES
    public void depositar(){
        int montoDepositado; //variable creada de tipo entero.
        do{
         try{
             System.out.println("¿Qué monto desea depositar en su cuenta?.");
             montoDepositado=sc.nextInt();
             if(montoDepositado<=0){
                 System.out.println("¡El monto a depositar debe ser mayor a cero!");
             } else {
                 this.saldo+=montoDepositado;
                 System.out.println("====¡Deposito realizado de manera exitosa!====");
                 System.out.println("Tu nuevo saldo es $ " + this.saldo + "\n");
             }  
            }catch(InputMismatchException e){
                System.out.println("****¡ERROR!****");
                System.out.println("Debes ingresar un monto valido.");
                sc.next();
                montoDepositado=0;   
            } 
        } while (montoDepositado<=0);
    }
    
    //METODOS ABSTRACTOS
    public abstract void calcularInteres();
    
    public abstract  void girar();
    
    
     //METODOS ADICIONALES -> corroboro que la cuenta que me ingresa la persona efectivamente tiene 9 digitos.
    public String cuentaValida(String cadena){
     String regex="^[0-9]{9}$";
     while(!cadena.matches(regex)){
         System.out.println("****¡ERROR!****");
         System.out.println("El numero de cuenta debe contener nueve digitos.");
         cadena=sc.next();
     }
     return cadena;
    }
    
}
