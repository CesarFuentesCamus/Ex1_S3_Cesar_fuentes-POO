
package cl.bankhouston.ejecutable;

import cl.bankhouston.entidades.Banco;
import cl.cliente.Cliente;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        
        Banco banco = new Banco("Bank Houston");
        
        Scanner sc = new Scanner (System.in);
        
        //MENU BANK HOUSTON
        Cliente elCliente =null;
        int opcionMenu=0;
        
        do{
            try{
                System.out.println("======================================");
                System.out.println("         Menu " + banco.getNombre().toUpperCase());
                System.out.println("=======================================");
                System.out.println("1.-Registrar cliente.");
                System.out.println("2.-Ver datos cliente.");
                System.out.println("3.-Depositar.");
                System.out.println("4.-Girar.");
                System.out.println("5.-Consultar Saldo.");
                System.out.println("6.-Salir.");
                System.out.println("======================================");
                System.out.println("                                      ");
                System.out.println("======================================");
                
                opcionMenu=sc.nextInt(); 
            }catch(InputMismatchException e){
                sc.nextLine();
                System.out.println(">>>>>>>>Entrada invalida<<<<<<<<<");
                System.out.println("Ingrese una opcion numerica del 1  al 6");
            }
            
              switch(opcionMenu){
                  case 1:
                      System.out.println(">>>>>>>> REGISTRO CLIENTE<<<<<<<<");
                      banco.registroCliente();
                      break;
                      //preguntar porque acá elimino el add de agregar a la lista.
                  case 2:
                      System.out.println(">>>>>>>> VISUALIZAR DATOS<<<<<<<<");
                      System.out.println("Elige el cliente que desea visualizar datos.");
                      
                      if(banco.cantidadClientes()){
                          System.out.println("No hay clientes registrados.");
                      }else{
                          banco.clienteElegido().datosCliente();
                      }
                      break;
                  case 3:
                      System.out.println(">>>>>>>> DEPOSITAR<<<<<<<<");
                      System.out.println("Elige el cliente que desea visualizar datos.");
                      
                      if(banco.cantidadClientes()){
                          System.out.println("No hay clientes registrados.");
                      }else{
                          elCliente=banco.clienteElegido();
                        if(elCliente.getLaCuenta() !=null && !elCliente.getLaCuenta().isEmpty()){
                            switch(elCliente.getLaCuenta()){
                                case "Cuenta_Corriente":
                                    elCliente.getCuentaCorriente().depositar();
                                    break;
                                case "Cuenta_Ahorro":
                                    elCliente.getCuentaAhorros().depositar();
                                    break;
                                case "Cuenta_Inversion":
                                    elCliente.getCuentaInversion().depositar();  
                                    break;
                            }
                        }    
                    }
                      break;
                      
                  case 4:
                      System.out.println(">>>>>>>> GIRAR <<<<<<<<");
                      System.out.println("Elige el cliente que desea visualizar datos.");
                     
                      if(banco.cantidadClientes()){
                          System.out.println("No hay clientes registrados.");
                      }else{
                          elCliente=banco.clienteElegido();
                          if(elCliente.getLaCuenta()!= null && !elCliente.getLaCuenta().isEmpty())
                              switch(elCliente.getLaCuenta()){
                                case "Cuenta_Corriente":
                                    elCliente.getCuentaCorriente().girar();
                                    break;
                                case "Cuenta_Ahorro":
                                    elCliente.getCuentaAhorros().girar();
                                    break;
                                case "Cuenta_Inversion":
                                    elCliente.getCuentaInversion().girar();  
                                    break;
                              }
                      }
                      break;
                  case 5:
                     System.out.println(">>>>>>>> CONSULTAR SALDO <<<<<<<<"); 
                     System.out.println("Elige el cliente que desea visualizar datos.");
                     if(banco.cantidadClientes()){
                         System.out.println("No hay clientes registrados");
                     }else{
                         banco.clienteElegido().datosCuenta();
                     }
                     break;
              }
            } while(opcionMenu!=6);
        
        System.out.println("===== Has salido de la aplicación " + banco.getNombre().toUpperCase() + "===");
        }
   
    }

