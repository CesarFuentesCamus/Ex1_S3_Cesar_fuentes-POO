
package cl.cliente;

import cl.bankhouston.entidades.CuentaAhorros;
import cl.bankhouston.entidades.CuentaCorriente;
import cl.bankhouston.entidades.CuentaInversion;
import java.util.Scanner;


public class Cliente implements InfoCliente{
    
    Scanner sc = new Scanner (System.in);
    
    //ATRIBUTOS ENCAPSULADOS.
    private String rut;
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String domicilio;
    private String comnuna;
    private String telefono;
    private String numeroDeCuenta;
    private CuentaCorriente cuentaCorriente;  //Declaro como atributos mis subclases creadas
    private CuentaAhorros cuentaAhorros;      //creando de esta forma una dependencia de clases
    private CuentaInversion cuentaInversion;  //Es decir, mi clase cliente depende de las 3 subclases. 
    private String laCuenta;
    
    //CONSTRUCTOR VACIO -> Ya que le pedire al cliente que me ingrese sus datos. 
    public Cliente() {
    }
    
    //GETTERS O ACCESADORES
    public String getNombre() {
        return nombre;
    }

    public CuentaCorriente getCuentaCorriente() {
        return cuentaCorriente;
    }

    public CuentaAhorros getCuentaAhorros() {
        return cuentaAhorros;
    }

    public CuentaInversion getCuentaInversion() {
        return cuentaInversion;
    }

    public String getLaCuenta() {
        return laCuenta;
    }
    
    //METODOS
    public void nuevaCuenta(String tipo){
        switch(tipo){
            case "Cuenta_Corriente":
                this.cuentaCorriente=new CuentaCorriente();
                break;
            case "Cuenta_Ahorro":
                this.cuentaAhorros= new CuentaAhorros();
                break;
            case "Cuenta_Inversion":
                this.cuentaInversion= new CuentaInversion();
                
        }
    }
    
    //METODOS PROVIENTES DE LA INTERFAZ
    @Override
    public void datosCliente() {
        System.out.println("Rut: " + this.rut);
        System.out.println("Nombre: " + this.nombre);
        System.out.println("Apellido Paterno: " + this.apellidoPaterno);
        System.out.println("Apellido Materno: " + this.apellidoMaterno);
        System.out.println("Domicilio: " + this.domicilio);
        System.out.println("Comuna: " + this.comnuna);
        System.out.println("telefono " + this.telefono);
    }

    @Override
    public void datosCuenta() {
        System.out.println("Numero de Cuenta: " + this.numeroDeCuenta);
        if(this.cuentaCorriente !=null){
            System.out.println(this.cuentaCorriente.getTipoDeCuenta());
            System.out.println("Saldo : $ " + this.cuentaCorriente.getSaldo());
        }
        if(this.cuentaAhorros !=null){
            System.out.println(this.cuentaAhorros.getTipoDeCuenta());
            System.out.println("Saldo : $ " + this.cuentaAhorros.getSaldo());
        }
        if(this.cuentaInversion !=null){
            System.out.println(this.cuentaInversion.getTipoDeCuenta());
            System.out.println("Saldo : $ " + this.cuentaInversion.getSaldo());
        }
    }
    
    //SETTERS O MUTADORES.

    public void setRut(String rut) {
        this.rut = validacionRut(rut);
    }

    public void setNombre(String nombre) {
        this.nombre = validacionString(nombre);
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = validacionString(apellidoPaterno);
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = validacionString(apellidoMaterno);
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public void setComnuna(String comuna) {
        this.comnuna = validacionString(comuna);
    }

    public void setTelefono(String telefono) {
        this.telefono = validacionNumeros(telefono);
    }

    public void setNumeroDeCuenta(String numeroDeCuenta) {
        this.numeroDeCuenta = validacionNumeros(numeroDeCuenta);
    }

    public void setLaCuenta(String tipoDeCuenta) {
        this.laCuenta = tipoDeCuenta;
    }
    
    
    //METODOS DE VALIDACIÓN DE CARACTERES Y NUMEROS RESPECTIVAMENTE.
    public boolean sonCaracteres(String validarString){
        return validarString.matches("^[a-zA-Z]+$");
    }
    public boolean sonNumeros(String validarNumero){
        return validarNumero.matches("^[0-9]{9}$");
    }
    
    public String validacionString(String entrada){
        while(!sonCaracteres(entrada)){
            System.out.println("====¡Entrada invalida!=====");
            System.out.println("Este campo solo debe contener caracteres.");
            entrada=sc.next();   
        }
        return entrada;
    }
    
    private String validacionNumeros(String entrada){
        while(!sonNumeros(entrada)){
            System.out.println("====¡Entrada invalida!=====");
            System.out.println("Este campo solo debe contener 9 digitos.");
            entrada=sc.next();
        }
        return entrada;
    }
    
    public String validacionRut(String entrada){
        while(entrada.length()!=11 && entrada.length()!=12){
            System.out.println(">>>>ENTRADA INVALIDA<<<<");
            System.out.println("El rut debe contener entre 11 a 12 caracteres");
            entrada=sc.next();
        }
        return entrada;
    }

    
    
    
}
