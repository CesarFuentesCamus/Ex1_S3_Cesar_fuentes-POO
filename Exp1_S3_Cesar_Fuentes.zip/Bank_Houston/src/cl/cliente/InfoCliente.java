
package cl.cliente;


public interface InfoCliente {
    
    
    //METODOS EMPLEADOS
    public void datosCliente();
    
    public void datosCuenta();
}
